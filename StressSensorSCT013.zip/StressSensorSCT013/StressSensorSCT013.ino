/*
  ============================================================
       NEOTECH SCT-013-030 CURRENT MONITOR V5 (ULTRA ROBUST)
  ============================================================

  BOARD       : ESP32 DevKit V1
  SENSOR      : SCT-013-030 (30A / 1V RMS)
  ADC         : GPIO34 (ADC1)
  NETWORK     : WiFi Station
  WEB SERVER  : Port 80

  TARGET      : 3-Phase Industrial Motor Monitoring (Anti-Hang & Noise Resistant)
  
  ARCHITECTURE:
  Core 0 : WiFi + WebServer + TWDT Reset
  Core 1 : ADC sampling (2 kHz) + True RMS calculation + TWDT Reset
  Timer  : 0.5 ms periodic sampling notification (esp_timer)

  FEATURES:
  - Task Watchdog Timer (TWDT) Anti-Freeze Recovery
  - Fully Non-Blocking Architecture (Zero delay() / millis() based)
  - True RMS calculation
  - 4x ADC Oversampling (Glitch Filtering)
  - Aggressive Industrial Noise Deadband
  - Heavy EMA Smoothing Filter (EMA_ALPHA 0.05)
  - WiFi Stack Auto-Reset State Machine
  - Shared data protected by Critical Section
  ============================================================
*/

#include <Arduino.h>
#include <WiFi.h>
#include <WebServer.h>
#include <Preferences.h>
#include <esp_timer.h>
#include <esp_system.h>
#include <esp_task_wdt.h>
#include <math.h>
#include <stdlib.h>

// ============================================================
// 1. WATCHDOG & WIFI CONFIGURATION
// ============================================================

#define TWDT_TIMEOUT_S 5 // Timeout Watchdog 5 detik

const char* WIFI_SSID = "Hovsky";
const char* WIFI_PASS = "passwordapa";

// ============================================================
// 2. SENSOR & INDUSTRIAL MOTOR TUNING (ALGORITMA ASLI)
// ============================================================

#define SCT_PIN 34

static constexpr float SENSOR_RATIO = 30.0f;
static constexpr float SENSOR_MAX_VOLT = 1.0f;

// Zero Cutoff memotong noise induksi fasa tetangga motor 3-phase
static constexpr float ZERO_CUTOFF_A = 0.40f;

// Timer sampling interval: 500 us = 0.5 ms = 2 kHz sampling rate
static constexpr uint64_t SAMPLE_INTERVAL_US = 500;

// RMS calculation window (200 ms = 10 siklus gelombang 50Hz)
static constexpr uint32_t SAMPLE_WINDOW_MS = 200;

// ============================================================
// 3. OBJECTS
// ============================================================

WebServer server(80);
Preferences preferences;

esp_timer_handle_t sampleTimer = nullptr;
TaskHandle_t sampleTaskHandle = nullptr;
TaskHandle_t webTaskHandle = nullptr;

// ============================================================
// 4. SHARED DATA
// ============================================================

portMUX_TYPE dataMux = portMUX_INITIALIZER_UNLOCKED;

struct MeasurementData {
    float currentA;
    float rawCurrentA;

    float rmsVoltage;
    float meanVoltage;

    float calibration;

    uint32_t minMv;
    uint32_t maxMv;
    uint32_t samples;

    bool overRange;
    bool valid;
};

MeasurementData measurement = {
    0.0f,
    0.0f,
    0.0f,
    0.0f,
    1.0f,
    0,
    0,
    0,
    false,
    false
};

// ============================================================
// 5. SYSTEM VARIABLES
// ============================================================

float calibrationFactor = 1.0f;

uint32_t bootTimeMs = 0;
uint32_t lastReconnectMs = 0;
uint32_t lastDiagnosticMs = 0;
uint32_t wifiFailCount = 0;

bool wifiWasConnected = false;

static constexpr uint32_t WIFI_RECONNECT_MS = 10000;
static constexpr uint32_t DIAGNOSTIC_INTERVAL_MS = 5000;

// ============================================================
// 6. HTML DASHBOARD
// ============================================================

const char INDEX_HTML[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">

<title>NEOTECH 3-PHASE MOTOR MONITOR V5</title>

<style>
* {
    box-sizing: border-box;
}

body {
    margin: 0;
    background: #07111f;
    color: #eaf2ff;
    font-family: Arial, sans-serif;
}

.header {
    padding: 20px;
    background: #0c1b2e;
    border-bottom: 1px solid #20354f;
}

.header h2 {
    margin: 0;
    color: #36a3ff;
}

.header small {
    color: #8ca6c4;
}

.container {
    max-width: 1100px;
    margin: auto;
    padding: 18px;
}

.grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 15px;
}

.card {
    background: #102239;
    padding: 20px;
    border-radius: 14px;
    border: 1px solid #203b59;
}

.card-title {
    color: #8ca6c4;
    font-size: 13px;
    margin-bottom: 12px;
}

.value {
    font-size: 30px;
    font-weight: bold;
    color: white;
}

.unit {
    color: #8ca6c4;
    font-size: 14px;
}

.status {
    display: inline-block;
    padding: 7px 12px;
    border-radius: 20px;
    font-size: 12px;
    background: #26384c;
}

.online {
    background: #124c36;
    color: #69f0ae;
}

.offline {
    background: #57252c;
    color: #ff9292;
}

canvas {
    width: 100%;
    height: 220px;
    background: #09182a;
    border-radius: 10px;
}

input {
    width: 100%;
    padding: 12px;
    margin-top: 8px;
    border: 1px solid #35516e;
    border-radius: 8px;
    background: #07182b;
    color: white;
    font-size: 16px;
}

button {
    width: 100%;
    margin-top: 10px;
    padding: 12px;
    border: none;
    border-radius: 8px;
    background: #1685e8;
    color: white;
    font-weight: bold;
    cursor: pointer;
}

button.secondary {
    background: #455b73;
}

.info {
    color: #8ca6c4;
    font-size: 12px;
    line-height: 1.7;
}

.footer {
    text-align: center;
    color: #647c98;
    padding: 25px;
    font-size: 12px;
}
</style>
</head>

<body>

<div class="header">
    <h2>NEOTECH MOTOR CURRENT MONITOR</h2>
    <small>SCT-013-030 | ESP32 | INDUSTRIAL V5</small>
</div>

<div class="container">

    <div class="grid">

        <div class="card">
            <div class="card-title">MOTOR CURRENT RMS</div>
            <div class="value" id="current">0.000</div>
            <div class="unit">Ampere (A)</div>
        </div>

        <div class="card">
            <div class="card-title">SENSOR RMS VOLTAGE</div>
            <div class="value" id="voltage">0.0000</div>
            <div class="unit">Volt (V)</div>
        </div>

        <div class="card">
            <div class="card-title">WIFI STATUS</div>
            <div id="wifi" class="status offline">DISCONNECTED</div>
            <p class="info" id="ip">IP: -</p>
            <p class="info" id="rssi">RSSI: -</p>
        </div>

        <div class="card">
            <div class="card-title">SENSOR STATUS</div>
            <div id="sensor" class="status offline">WAITING</div>
            <p class="info" id="samples">Samples: 0</p>
            <p class="info" id="uptime">Uptime: 0 s</p>
        </div>

    </div>

    <br>

    <div class="card">
        <div class="card-title">REALTIME MOTOR CURRENT GRAPH</div>
        <canvas id="chart" width="900" height="250"></canvas>
    </div>

    <br>

    <div class="grid">

        <div class="card">
            <div class="card-title">ADC DIAGNOSTIC</div>

            <p class="info">DC Bias / Mean Voltage</p>
            <div class="value" id="mean">0.000</div>
            <div class="unit">Volt</div>

            <br>

            <p class="info">ADC Minimum / Maximum</p>
            <div class="value" style="font-size:21px" id="range">
                0 / 0
            </div>
            <div class="unit">mV</div>

            <br>

            <p class="info">Raw Current Before Calibration</p>
            <div class="value" style="font-size:22px" id="raw">
                0.000 A
            </div>
        </div>

        <div class="card">
            <div class="card-title">CALIBRATION</div>

            <p class="info">Calibration Factor</p>
            <div class="value" id="factor">1.000</div>

            <input
                id="newFactor"
                type="number"
                min="0.1"
                max="10"
                step="0.001"
                value="1.000"
            >

            <button onclick="saveCalibration()">
                SAVE CALIBRATION
            </button>

            <button class="secondary" onclick="resetCalibration()">
                RESET CALIBRATION
            </button>

            <p class="info" id="message">
                Calibration stored in ESP32.
            </p>
        </div>

    </div>

</div>

<div class="footer">
    NEOTECH SOFTWARE | INDUSTRIAL IOT MONITORING
</div>

<script>
"use strict";

const historyData = [];
const maxPoints = 60;

const canvas = document.getElementById("chart");
const ctx = canvas.getContext("2d");

function drawChart() {

    const w = canvas.width;
    const h = canvas.height;

    ctx.clearRect(0, 0, w, h);

    ctx.strokeStyle = "#203b59";
    ctx.lineWidth = 1;

    for (let i = 1; i <= 4; i++) {
        const y = h - (h / 5) * i;

        ctx.beginPath();
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
        ctx.stroke();
    }

    if (historyData.length < 2) return;

    let maxValue = 1;

    for (const v of historyData) {
        if (v > maxValue) maxValue = v;
    }

    maxValue *= 1.2;

    ctx.beginPath();
    ctx.strokeStyle = "#36a3ff";
    ctx.lineWidth = 3;

    historyData.forEach((value, index) => {

        const x = index * (w / (maxPoints - 1));
        const y = h - (value / maxValue) * (h - 15) - 5;

        if (index === 0) {
            ctx.moveTo(x, y);
        } else {
            ctx.lineTo(x, y);
        }
    });

    ctx.stroke();
}

async function updateDashboard() {

    try {

        const response = await fetch("/api/status", {
            cache: "no-store"
        });

        if (!response.ok) {
            throw new Error("HTTP " + response.status);
        }

        const d = await response.json();

        document.getElementById("current").textContent =
            Number(d.current).toFixed(3);

        document.getElementById("voltage").textContent =
            Number(d.rmsVoltage).toFixed(4);

        document.getElementById("mean").textContent =
            Number(d.meanVoltage).toFixed(3);

        document.getElementById("raw").textContent =
            Number(d.rawCurrent).toFixed(3) + " A";

        document.getElementById("factor").textContent =
            Number(d.calibration).toFixed(3);

        document.getElementById("samples").textContent =
            "Samples: " + d.samples;

        document.getElementById("uptime").textContent =
            "Uptime: " + d.uptime + " s";

        document.getElementById("range").textContent =
            d.minMv + " / " + d.maxMv;

        document.getElementById("ip").textContent =
            "IP: " + d.ip;

        document.getElementById("rssi").textContent =
            "RSSI: " + d.rssi + " dBm";

        const wifi = document.getElementById("wifi");

        wifi.textContent = d.wifi ? "CONNECTED" : "DISCONNECTED";
        wifi.className = d.wifi ? "status online" : "status offline";

        const sensor = document.getElementById("sensor");

        if (!d.valid) {
            sensor.textContent = "WAITING";
            sensor.className = "status offline";
        } else if (d.overRange) {
            sensor.textContent = "OVER RANGE";
            sensor.className = "status offline";
        } else {
            sensor.textContent = "NORMAL";
            sensor.className = "status online";
        }

        historyData.push(Number(d.current));

        if (historyData.length > maxPoints) {
            historyData.shift();
        }

        drawChart();

    } catch (error) {

        console.log("Dashboard error:", error);
    }
}

let requestBusy = false;

async function pollDashboard() {

    if (requestBusy) return;

    requestBusy = true;

    try {
        await updateDashboard();
    } finally {
        requestBusy = false;
    }
}

async function saveCalibration() {

    const factor = Number(
        document.getElementById("newFactor").value
    );

    if (!Number.isFinite(factor) || factor < 0.1 || factor > 10) {

        document.getElementById("message").textContent =
            "Factor must be between 0.1 and 10.";

        return;
    }

    try {

        const body = new URLSearchParams();
        body.append("factor", String(factor));

        const response = await fetch("/api/calibrate", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            body: body.toString()
        });

        const result = await response.json();

        document.getElementById("message").textContent =
            result.message;

        await pollDashboard();

    } catch (error) {

        document.getElementById("message").textContent =
            "Calibration request failed.";
    }
}

async function resetCalibration() {

    try {

        const response = await fetch("/api/reset", {
            method: "POST"
        });

        const result = await response.json();

        document.getElementById("message").textContent =
            result.message;

        document.getElementById("newFactor").value = "1.000";

        await pollDashboard();

    } catch (error) {

        document.getElementById("message").textContent =
            "Reset request failed.";
    }
}

setInterval(pollDashboard, 1000);

pollDashboard();

</script>

</body>
</html>
)rawliteral";

// ============================================================
// 7. SNAPSHOT FUNCTION
// ============================================================

MeasurementData getMeasurementSnapshot()
{
    MeasurementData copy;

    portENTER_CRITICAL(&dataMux);
    copy = measurement;
    portEXIT_CRITICAL(&dataMux);

    return copy;
}

// ============================================================
// 8. SAMPLE TIMER CALLBACK
// ============================================================

void sampleTimerCallback(void* argument)
{
    (void)argument;

    if (sampleTaskHandle != nullptr) {
        xTaskNotifyGive(sampleTaskHandle);
    }
}

// ============================================================
// 9. MEASUREMENT TASK (CORE 1 - ALGORITMA UTUH + WATCHDOG)
// ============================================================

void measurementTask(void* parameter)
{
    (void)parameter;

    // Registrasi Task ini ke Watchdog Timer
    esp_task_wdt_add(NULL);

    double sum = 0.0;
    double sumSquare = 0.0;

    uint32_t count = 0;

    uint32_t minMv = 5000;
    uint32_t maxMv = 0;

    int64_t windowStartUs = esp_timer_get_time();

    float filteredCurrent = 0.0f;
    const float EMA_ALPHA = 0.05f;

    for (;;) {
        // Feed Watchdog setiap siklus eksekusi
        esp_task_wdt_reset();

        uint32_t notifications = ulTaskNotifyTake(pdTRUE, pdMS_TO_TICKS(100));

        if (notifications == 0) continue;

        // 1. Oversampling 4x ADC
        uint32_t rawMvSum = 0;
        for (int i = 0; i < 4; i++) {
            rawMvSum += analogReadMilliVolts(SCT_PIN);
        }
        uint32_t mv = rawMvSum / 4;

        if (mv > 3300) mv = 3300;

        const double voltage = (double)mv / 1000.0;

        sum += voltage;
        sumSquare += voltage * voltage;

        count++;

        if (mv < minMv) minMv = mv;
        if (mv > maxMv) maxMv = mv;

        const int64_t nowUs = esp_timer_get_time();

        if ((nowUs - windowStartUs) >= ((int64_t)SAMPLE_WINDOW_MS * 1000LL)) {

            if (count >= 100) {
                const double mean = sum / (double)count;
                double variance = (sumSquare / (double)count) - (mean * mean);

                // 2. Variance Deadband Industrial
                if (variance < 0.0010) {
                    variance = 0.0;
                }

                const float rmsVoltage = (float)sqrt(variance);
                const float rawCurrent = rmsVoltage * SENSOR_RATIO;

                float factor;
                portENTER_CRITICAL(&dataMux);
                factor = calibrationFactor;
                portEXIT_CRITICAL(&dataMux);

                float calibratedCurrent = rawCurrent * factor;

                // 3. Zero Cutoff & Heavy EMA Filter
                if (calibratedCurrent < ZERO_CUTOFF_A) {
                    calibratedCurrent = 0.0f;
                    filteredCurrent = 0.0f;
                } else {
                    filteredCurrent = (EMA_ALPHA * calibratedCurrent) + ((1.0f - EMA_ALPHA) * filteredCurrent);
                }

                const bool overRange = rmsVoltage > SENSOR_MAX_VOLT;

                portENTER_CRITICAL(&dataMux);

                measurement.currentA = filteredCurrent;
                measurement.rawCurrentA = rawCurrent;
                measurement.rmsVoltage = rmsVoltage;
                measurement.meanVoltage = (float)mean;
                measurement.calibration = factor;
                measurement.minMv = minMv;
                measurement.maxMv = maxMv;
                measurement.samples = count;
                measurement.overRange = overRange;
                measurement.valid = true;

                portEXIT_CRITICAL(&dataMux);
            }

            sum = 0.0;
            sumSquare = 0.0;
            count = 0;
            minMv = 5000;
            maxMv = 0;
            windowStartUs = nowUs;
        }
    }
}

// ============================================================
// 10. NON-BLOCKING WIFI RECOVERY STATE MACHINE
// ============================================================

void startWiFi()
{
    WiFi.mode(WIFI_STA);
    WiFi.setAutoReconnect(true);
    WiFi.persistent(false);

    WiFi.begin(WIFI_SSID, WIFI_PASS);

    lastReconnectMs = millis();
    Serial.println("WiFi connection requested.");
}

void handleWiFi()
{
    const uint32_t now = millis();
    const bool connected = (WiFi.status() == WL_CONNECTED);

    if (connected) {
        if (!wifiWasConnected) {
            wifiWasConnected = true;
            wifiFailCount = 0;
            Serial.println();
            Serial.println("===== WIFI CONNECTED =====");
            Serial.print("IP: "); Serial.println(WiFi.localIP());
            Serial.print("RSSI: "); Serial.println(WiFi.RSSI());
            Serial.println("==========================");
        }
        return;
    }

    if (wifiWasConnected) {
        wifiWasConnected = false;
        Serial.println("WiFi disconnected.");
    }

    // Interval Reconnect Non-blocking menggunakan millis()
    if (now - lastReconnectMs >= WIFI_RECONNECT_MS) {
        lastReconnectMs = now;
        wifiFailCount++;
        Serial.printf("WiFi reconnect attempt #%u...\n", wifiFailCount);

        // Jika terputus >6x (1 menit) akibat noise RF tinggi, lakukan soft-reset driver WiFi
        if (wifiFailCount > 6) {
            Serial.println("Resetting WiFi Subsystem Hardware...");
            WiFi.disconnect(true);
            WiFi.begin(WIFI_SSID, WIFI_PASS);
            wifiFailCount = 0;
        } else {
            WiFi.reconnect();
        }
    }
}

// ============================================================
// 11. STATUS API
// ============================================================

void handleStatus()
{
    const MeasurementData d = getMeasurementSnapshot();
    const bool wifiConnected = (WiFi.status() == WL_CONNECTED);

    const String ip = wifiConnected ? WiFi.localIP().toString() : "0.0.0.0";
    const int rssi = wifiConnected ? WiFi.RSSI() : 0;
    const uint32_t uptime = (millis() - bootTimeMs) / 1000;

    String json;
    json.reserve(400);

    json = "{";
    json += "\"current\":" + String(d.currentA, 4) + ",";
    json += "\"rawCurrent\":" + String(d.rawCurrentA, 4) + ",";
    json += "\"rmsVoltage\":" + String(d.rmsVoltage, 5) + ",";
    json += "\"meanVoltage\":" + String(d.meanVoltage, 4) + ",";
    json += "\"calibration\":" + String(d.calibration, 4) + ",";
    json += "\"minMv\":" + String(d.minMv) + ",";
    json += "\"maxMv\":" + String(d.maxMv) + ",";
    json += "\"samples\":" + String(d.samples) + ",";
    json += "\"uptime\":" + String(uptime) + ",";
    json += "\"wifi\":" + String(wifiConnected ? "true" : "false") + ",";
    json += "\"valid\":" + String(d.valid ? "true" : "false") + ",";
    json += "\"overRange\":" + String(d.overRange ? "true" : "false") + ",";
    json += "\"ip\":\"" + ip + "\",";
    json += "\"rssi\":" + String(rssi);
    json += "}";

    server.sendHeader("Cache-Control", "no-store");
    server.send(200, "application/json", json);
}

// ============================================================
// 12. CALIBRATION API
// ============================================================

void handleCalibration()
{
    if (!server.hasArg("factor")) {
        server.send(400, "application/json", "{\"success\":false,\"message\":\"Missing factor.\"}");
        return;
    }

    const String input = server.arg("factor");
    char* endPointer = nullptr;
    const float newFactor = strtof(input.c_str(), &endPointer);

    if (endPointer == input.c_str() || *endPointer != '\0' || !isfinite(newFactor) || newFactor < 0.1f || newFactor > 10.0f) {
        server.send(400, "application/json", "{\"success\":false,\"message\":\"Invalid factor. Use 0.1 to 10.\"}");
        return;
    }

    portENTER_CRITICAL(&dataMux);
    calibrationFactor = newFactor;
    measurement.calibration = newFactor;
    portEXIT_CRITICAL(&dataMux);

    preferences.putFloat("factor", newFactor);

    server.send(200, "application/json", "{\"success\":true,\"message\":\"Calibration saved successfully.\"}");
    Serial.printf("Calibration updated: %.4f\n", newFactor);
}

// ============================================================
// 13. RESET CALIBRATION API
// ============================================================

void handleResetCalibration()
{
    portENTER_CRITICAL(&dataMux);
    calibrationFactor = 1.0f;
    measurement.calibration = 1.0f;
    portEXIT_CRITICAL(&dataMux);

    preferences.putFloat("factor", 1.0f);

    server.send(200, "application/json", "{\"success\":true,\"message\":\"Calibration reset to 1.0.\"}");
    Serial.println("Calibration reset.");
}

// ============================================================
// 14. WEB ROUTES
// ============================================================

void startWebServer()
{
    server.on("/", HTTP_GET, []() {
        server.send_P(200, "text/html", INDEX_HTML);
    });

    server.on("/api/status", HTTP_GET, handleStatus);
    server.on("/api/calibrate", HTTP_POST, handleCalibration);
    server.on("/api/reset", HTTP_POST, handleResetCalibration);

    server.onNotFound([]() {
        server.send(404, "text/plain", "404 Not Found");
    });

    server.begin();
    Serial.println("WebServer started on port 80.");
}

// ============================================================
// 15. SERIAL DIAGNOSTIC
// ============================================================

void handleDiagnostic()
{
    const uint32_t now = millis();
    if (now - lastDiagnosticMs < DIAGNOSTIC_INTERVAL_MS) return;

    lastDiagnosticMs = now;
    const MeasurementData d = getMeasurementSnapshot();

    Serial.println();
    Serial.println("========== V5 DIAGNOSTIC ==========");
    Serial.printf("UPTIME          : %lu s\n", (unsigned long)((now - bootTimeMs) / 1000));
    Serial.printf("WIFI            : %s\n", WiFi.status() == WL_CONNECTED ? "CONNECTED" : "DISCONNECTED");

    if (WiFi.status() == WL_CONNECTED) {
        Serial.printf("IP              : %s\n", WiFi.localIP().toString().c_str());
        Serial.printf("RSSI            : %d dBm\n", WiFi.RSSI());
    }

    Serial.printf("MOTOR CURRENT   : %.3f A\n", d.currentA);
    Serial.printf("RAW CURRENT     : %.3f A\n", d.rawCurrentA);
    Serial.printf("RMS VOLTAGE     : %.5f V\n", d.rmsVoltage);
    Serial.printf("MEAN VOLTAGE    : %.4f V\n", d.meanVoltage);
    Serial.printf("ADC MIN / MAX   : %lu / %lu mV\n", (unsigned long)d.minMv, (unsigned long)d.maxMv);
    Serial.printf("SAMPLES         : %lu\n", (unsigned long)d.samples);
    Serial.printf("CALIBRATION     : %.3f\n", d.calibration);
    Serial.printf("OVER RANGE      : %s\n", d.overRange ? "YES" : "NO");
    Serial.printf("FREE HEAP       : %u bytes\n", ESP.getFreeHeap());
    Serial.printf("MIN FREE HEAP   : %u bytes\n", ESP.getMinFreeHeap());
    Serial.println("===================================");
}

// ============================================================
// 17. WEB / WIFI TASK ON CORE 0 (SERTA WATCHDOG RESET)
// ============================================================

void webTask(void* parameter)
{
    (void)parameter;

    // Registrasi Task Core 0 ke Watchdog Timer
    esp_task_wdt_add(NULL);

    for (;;) {
        // Feed Watchdog Core 0
        esp_task_wdt_reset();

        handleWiFi();
        server.handleClient();
        handleDiagnostic();

        // Non-blocking yield ke RTOS scheduler (2ms)
        vTaskDelay(pdMS_TO_TICKS(2));
    }
}

// ============================================================
// 16. SETUP (CLEAN DUAL CORE INITIATION)
// ============================================================

void setup()
{
    Serial.begin(115200);
    bootTimeMs = millis();

    Serial.println();
    Serial.println("========================================");
    Serial.println(" NEOTECH 3-PHASE MOTOR MONITOR V5");
    Serial.println("========================================");

    Serial.printf("Reset reason: %d\n", (int)esp_reset_reason());

    // 1. Inisialisasi Task Watchdog Timer System
#if defined(ESP_IDF_VERSION_MAJOR) && ESP_IDF_VERSION_MAJOR >= 5
    esp_task_wdt_config_t twdt_config = {
        .timeout_ms = TWDT_TIMEOUT_S * 1000,
        .idle_core_mask = (1 << portNUM_PROCESSORS) - 1,
        .trigger_panic = true
    };
    esp_task_wdt_reconfigure(&twdt_config);
#else
    esp_task_wdt_init(TWDT_TIMEOUT_S, true);
#endif

    // 2. ADC Hardware Config
    analogReadResolution(12);
    analogSetPinAttenuation(SCT_PIN, ADC_11db);
    pinMode(SCT_PIN, INPUT);

    // 3. Load EEPROM Preferences
    preferences.begin("sct-monitor", false);
    float storedFactor = preferences.getFloat("factor", 1.0f);

    if (!isfinite(storedFactor) || storedFactor < 0.1f || storedFactor > 10.0f) {
        storedFactor = 1.0f;
    }

    calibrationFactor = storedFactor;

    portENTER_CRITICAL(&dataMux);
    measurement.calibration = calibrationFactor;
    portEXIT_CRITICAL(&dataMux);

    Serial.printf("Calibration loaded: %.3f\n", calibrationFactor);

    // 4. Start WiFi & Server
    startWiFi();
    startWebServer();

    // 5. Create Web Server Task di Core 0 (Priority 1)
    BaseType_t webTaskResult = xTaskCreatePinnedToCore(
        webTask,
        "SCT_WebServer",
        8192,
        nullptr,
        1,
        &webTaskHandle,
        0
    );

    if (webTaskResult != pdPASS) {
        Serial.println("ERROR: Web Task creation failed!");
    } else {
        Serial.println("Web Task started on Core 0.");
    }

    // 6. Create Measurement Task di Core 1 (Priority 2 - Lebih Tinggi)
    BaseType_t sampleTaskResult = xTaskCreatePinnedToCore(
        measurementTask,
        "SCT_Measurement",
        4096,
        nullptr,
        2,
        &sampleTaskHandle,
        1
    );

    if (sampleTaskResult != pdPASS) {
        Serial.println("ERROR: Measurement Task creation failed!");
        sampleTaskHandle = nullptr;
        return;
    }

    // 7. Periodic Sampling Timer 2 kHz Setup
    esp_timer_create_args_t timerArgs = {};
    timerArgs.callback = &sampleTimerCallback;
    timerArgs.arg = nullptr;
    timerArgs.dispatch_method = ESP_TIMER_TASK;
    timerArgs.name = "SCT_SAMPLE_TIMER";

    esp_err_t timerResult = esp_timer_create(&timerArgs, &sampleTimer);
    if (timerResult != ESP_OK) {
        Serial.printf("ERROR: Timer creation failed: %d\n", (int)timerResult);
        return;
    }

    timerResult = esp_timer_start_periodic(sampleTimer, SAMPLE_INTERVAL_US);
    if (timerResult != ESP_OK) {
        Serial.printf("ERROR: Timer start failed: %d\n", (int)timerResult);
        return;
    }

    Serial.println("Measurement Task started on Core 1.");
    Serial.println("Sampling timer started (2 kHz).");
    Serial.println("V5 ULTRA-ROBUST SYSTEM INITIALIZED.");
}

// ============================================================
// 18. MAIN LOOP (PURE IDLE WATCHDOG TICK)
// ============================================================

void loop()
{
    // Main loop tidak mengeksekusi logika apapun.
    // Tugas murni dilakukan oleh Core 0 (Web) dan Core 1 (ADC Measurement).
    vTaskDelay(pdMS_TO_TICKS(1000));
}